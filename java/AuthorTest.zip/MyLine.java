public class Invoice{
    Customer customer;
    int id;
    double amount;


    public String toString() {
        return "Invoice[(" + id+  ","+customer.name+"," + customer.discount +")]"; 
    }
}