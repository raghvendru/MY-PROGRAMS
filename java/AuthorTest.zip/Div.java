public class Div{

    public static void main(String[] args) {
         
       int num1=25, num2=4,div;
       div=num1/num2;
       System.out.println("div of these numbers:"+div);
    }
 }