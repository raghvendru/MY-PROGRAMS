public class AddTwoNumbers {

    public static void main(String[] args) {
         
       int a = 5, sum;
       sum = a+1;
 
       System.out.println("sum of these numbers: "+sum);
    }
 }