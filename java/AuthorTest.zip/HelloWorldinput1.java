/** Simple hello world program
 * by itfyme
 */

public class HelloWorldinput {
    public static void main(String[] args) {
         System.out.println("Hello"+ args[0]+ "! Welcome to Programming World!");
    }
}