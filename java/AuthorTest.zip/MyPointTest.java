public class MyPointTest{
   public static void main(String[] args)
   {
      MyPoint p1=new MyPoint(8,5);
      System.out.println(p1.distance(5, 6));
      MyPoint p2 = new MyPoint(3, 4);
      System.out.println(p1.distance(8,7));

     
   System.out.println(p1);
   System.out.println("x is" + p1.getX());
   System.out.println("y is" + p1.getY());
   System.out.println("xy is" + p1.getXY());

   System.out.println("x is" + p2.getX());
   System.out.println("y is" + p2.getY());
   System.out.println("xy is" + p2.getXY());
  
   int x1=this.x-x;
   int y1=this.y-y;
   int distance=Math.sqrt(x1 + y1);
   System.out.println(distance);
   }
}