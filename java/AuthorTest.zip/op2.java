public class AddTwoNumbers {

    public static void main(String[] args) {
         
       int a = 5, sum;
       sum = 5/2;
 
       System.out.println("Sum of these numbers: "+sum);
    }
 }class op2 {
    
}
